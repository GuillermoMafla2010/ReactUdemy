export const AUTH_CONFIG = {
  domain: 'cristianjativa.auth0.com',
  clientId: 'v2QHC5uHBCO5Zt4rhuXWikLysvxANC4k',
  callbackUrl: 'http://localhost:3000/callback'
}
